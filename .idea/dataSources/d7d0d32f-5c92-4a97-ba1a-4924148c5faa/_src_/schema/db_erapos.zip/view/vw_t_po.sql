CREATE VIEW vw_t_po AS
  SELECT
    `a`.`id`                                                           AS `id`,
    `a`.`outlet_id`                                                    AS `outlet_id`,
    `b`.`kode`                                                         AS `outlet_kode`,
    `b`.`outlet_name`                                                  AS `outlet_name`,
    `a`.`po_no`                                                        AS `po_no`,
    `a`.`po_date`                                                      AS `po_date`,
    `a`.`supp_code`                                                    AS `supp_code`,
    `c`.`nama`                                                         AS `supp_name`,
    `a`.`po_status`                                                    AS `po_status`,
    `a`.`notes`                                                        AS `notes`,
    `a`.`create_time`                                                  AS `create_time`,
    `a`.`createby_id`                                                  AS `createby_id`,
    `a`.`update_time`                                                  AS `update_time`,
    `a`.`updateby_id`                                                  AS `updateby_id`,
    `e`.`short_desc`                                                   AS `dpo_status`,
    coalesce(sum(((`d`.`qty_order` * `d`.`harga`) - `d`.`diskon`)), 0) AS `sub_total`
  FROM ((((`db_erapos`.`t_po` `a`
    JOIN `db_erapos`.`m_outlet` `b` ON ((`a`.`outlet_id` = `b`.`id`))) JOIN `db_erapos`.`m_supplier` `c`
      ON ((`a`.`supp_code` = `c`.`kode`))) JOIN `db_erapos`.`t_po_detail` `d` ON ((`a`.`po_no` = `d`.`po_no`))) JOIN
    `db_erapos`.`sys_status_code` `e` ON (((`a`.`po_status` = `e`.`code`) AND (`e`.`key` = 'trx_status'))))
  GROUP BY `a`.`po_no`;
