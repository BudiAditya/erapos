CREATE VIEW vw_t_sale_detail AS
  SELECT
    `a`.`outlet_id`                         AS `outlet_id`,
    `a`.`trx_no`                            AS `trx_no`,
    date_format(`a`.`trx_time`, '%Y-%m-%d') AS `trx_date`,
    `b`.`sku`                               AS `sku`,
    `c`.`nama`                              AS `nama`,
    `c`.`satuan`                            AS `satuan`,
    `b`.`qty`                               AS `qty`,
    `b`.`harga`                             AS `harga`,
    (`b`.`qty` * `b`.`harga`)               AS `jumlah`
  FROM ((`db_erapos`.`t_sale` `a`
    JOIN `db_erapos`.`t_sale_detail` `b` ON ((`b`.`trx_no` = `a`.`trx_no`))) JOIN `db_erapos`.`m_produk` `c`
      ON ((`b`.`sku` = `c`.`sku`)));
