CREATE VIEW vw_t_sale_sku_summary AS
  SELECT
    `a`.`sku`                      AS `sku`,
    `b`.`nama`                     AS `nama`,
    sum(`a`.`qty`)                 AS `sum_qty`,
    sum((`a`.`qty` * `a`.`harga`)) AS `sum_amount`
  FROM (`db_erapos`.`t_sale_detail` `a`
    JOIN `db_erapos`.`m_produk` `b` ON ((`a`.`sku` = `b`.`sku`)))
  GROUP BY `a`.`sku`;
