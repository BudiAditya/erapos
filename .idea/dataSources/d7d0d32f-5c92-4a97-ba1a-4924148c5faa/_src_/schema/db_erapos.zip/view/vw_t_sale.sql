CREATE VIEW vw_t_sale AS
  SELECT
    `a`.`id`          AS `id`,
    `a`.`outlet_id`   AS `outlet_id`,
    `c`.`kode`        AS `outlet_kode`,
    `c`.`outlet_name` AS `outlet_name`,
    `c`.`alamat`      AS `alamat`,
    `a`.`trx_no`      AS `trx_no`,
    `a`.`trx_time`    AS `trx_time`,
    `a`.`cust_code`   AS `cust_code`,
    `d`.`nama`        AS `cust_name`,
    `a`.`money_amt`   AS `money_amt`,
    `a`.`pay_amt`     AS `pay_amt`,
    `a`.`trx_status`  AS `trx_status`,
    `e`.`short_desc`  AS `dtrx_status`,
    `a`.`sub_total`   AS `sub_total`,
    `a`.`notes`       AS `notes`,
    `a`.`table_no`    AS `table_no`,
    `a`.`disc_pct`    AS `disc_pct`,
    `a`.`disc_amt`    AS `disc_amt`,
    `a`.`is_taxable`  AS `is_taxable`,
    `a`.`tax_pct`     AS `tax_pct`,
    `a`.`tax_amt`     AS `tax_amt`
  FROM (((`db_erapos`.`t_sale` `a`
    JOIN `db_erapos`.`m_outlet` `c` ON ((`a`.`outlet_id` = `c`.`id`))) JOIN `db_erapos`.`m_customer` `d`
      ON ((`a`.`cust_code` = `d`.`kode`))) JOIN `db_erapos`.`sys_status_code` `e`
      ON (((`a`.`trx_status` = `e`.`code`) AND (`e`.`key` = 'trx_status'))))
  WHERE (`a`.`trx_status` < 3)
  GROUP BY `a`.`trx_no`;
