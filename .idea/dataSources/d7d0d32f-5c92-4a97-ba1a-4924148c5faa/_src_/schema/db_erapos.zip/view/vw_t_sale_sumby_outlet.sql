CREATE VIEW vw_t_sale_sumby_outlet AS
  SELECT
    `a`.`outlet_id`          AS `outlet_id`,
    sum(`a`.`sale_per_date`) AS `sum_sale`
  FROM `db_erapos`.`vw_t_sale_outlet_sum_per_date` `a`
  GROUP BY `a`.`outlet_id`;
