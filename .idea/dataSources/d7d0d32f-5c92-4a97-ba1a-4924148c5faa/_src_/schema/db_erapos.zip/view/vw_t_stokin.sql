CREATE VIEW vw_t_stokin AS
  SELECT
    `a`.`id`                                                            AS `id`,
    `a`.`outlet_id`                                                     AS `outlet_id`,
    `b`.`kode`                                                          AS `outlet_kode`,
    `b`.`outlet_name`                                                   AS `outlet_name`,
    `a`.`stokin_no`                                                     AS `stokin_no`,
    `a`.`stokin_date`                                                   AS `stokin_date`,
    `a`.`supp_code`                                                     AS `supp_code`,
    `a`.`pay_amt`                                                       AS `pay_amt`,
    `c`.`nama`                                                          AS `supp_name`,
    `a`.`stokin_status`                                                 AS `stokin_status`,
    `a`.`ex_po_no`                                                      AS `ex_po_no`,
    `a`.`notes`                                                         AS `notes`,
    `a`.`create_time`                                                   AS `create_time`,
    `a`.`createby_id`                                                   AS `createby_id`,
    `a`.`update_time`                                                   AS `update_time`,
    `a`.`updateby_id`                                                   AS `updateby_id`,
    `e`.`short_desc`                                                    AS `dstokin_status`,
    coalesce(sum(((`d`.`qty_terima` * `d`.`harga`) - `d`.`diskon`)), 0) AS `sub_total`
  FROM ((((`db_erapos`.`t_stokin` `a`
    JOIN `db_erapos`.`m_outlet` `b` ON ((`a`.`outlet_id` = `b`.`id`))) JOIN `db_erapos`.`m_supplier` `c`
      ON ((`a`.`supp_code` = `c`.`kode`))) JOIN `db_erapos`.`t_stokin_detail` `d`
      ON ((`a`.`stokin_no` = `d`.`stokin_no`))) JOIN `db_erapos`.`sys_status_code` `e`
      ON (((`a`.`stokin_status` = `e`.`code`) AND (`e`.`key` = 'trx_status'))))
  GROUP BY `a`.`stokin_no`;
