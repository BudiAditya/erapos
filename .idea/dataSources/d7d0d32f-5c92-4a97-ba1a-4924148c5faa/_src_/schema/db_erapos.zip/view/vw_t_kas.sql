CREATE VIEW vw_t_kas AS
  SELECT
    `a`.`id`                                   AS `id`,
    `a`.`outlet_id`                            AS `outlet_id`,
    `a`.`trx_no`                               AS `trx_no`,
    `a`.`trx_date`                             AS `trx_date`,
    `a`.`trx_type`                             AS `trx_type`,
    `a`.`notes`                                AS `notes`,
    `a`.`jumlah`                               AS `jumlah`,
    `a`.`reff_no`                              AS `reff_no`,
    `a`.`trx_status`                           AS `trx_status`,
    `a`.`trx_mode`                             AS `trx_mode`,
    `a`.`create_time`                          AS `create_time`,
    `a`.`createby_id`                          AS `createby_id`,
    `a`.`update_time`                          AS `update_time`,
    `a`.`updateby_id`                          AS `updateby_id`,
    `b`.`kode`                                 AS `outlet_kode`,
    `b`.`outlet_name`                          AS `outlet_name`,
    `c`.`short_desc`                           AS `kas_status`,
    `d`.`short_desc`                           AS `trx_descs`,
    if((`a`.`trx_mode` = 1), 'Manual', 'Auto') AS `xmode`
  FROM (((`db_erapos`.`t_kas` `a`
    JOIN `db_erapos`.`m_outlet` `b` ON ((`a`.`outlet_id` = `b`.`id`))) JOIN `db_erapos`.`sys_status_code` `c`
      ON (((`a`.`trx_status` = `c`.`code`) AND (`c`.`key` = 'kas_status')))) JOIN `db_erapos`.`sys_status_code` `d`
      ON (((`a`.`trx_type` = `d`.`code`) AND (`d`.`key` = 'trx_type'))))
  ORDER BY `a`.`trx_no`, `b`.`kode`;
