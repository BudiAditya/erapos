CREATE VIEW vw_t_produksi AS
  SELECT
    `a`.`id`                                                                            AS `id`,
    `a`.`outlet_id`                                                                     AS `outlet_id`,
    `a`.`prod_no`                                                                       AS `prod_no`,
    `a`.`prod_date`                                                                     AS `prod_date`,
    `a`.`notes`                                                                         AS `notes`,
    `a`.`prod_status`                                                                   AS `prod_status`,
    if((`a`.`prod_status` = 1), 'Posted', if((`a`.`prod_status` = 3), 'Void', 'Draft')) AS `dprod_status`,
    `a`.`create_time`                                                                   AS `create_time`,
    `a`.`createby_id`                                                                   AS `createby_id`,
    `a`.`update_time`                                                                   AS `update_time`,
    `a`.`updateby_id`                                                                   AS `updateby_id`,
    `c`.`kode`                                                                          AS `outlet_kode`,
    `c`.`outlet_name`                                                                   AS `outlet_name`,
    coalesce(sum((`b`.`qty` * `b`.`harga`)), 0)                                         AS `sub_total`
  FROM ((`db_erapos`.`t_produksi` `a`
    JOIN `db_erapos`.`t_produksi_detail` `b` ON ((`a`.`prod_no` = `b`.`prod_no`))) JOIN `db_erapos`.`m_outlet` `c`
      ON ((`a`.`outlet_id` = `c`.`id`)))
  WHERE (`b`.`prod_type` = 1)
  GROUP BY `a`.`prod_no`;
