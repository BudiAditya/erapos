CREATE VIEW vw_t_payment AS
  SELECT
    `a`.`id`                                                                         AS `id`,
    `a`.`outlet_id`                                                                  AS `outlet_id`,
    `a`.`trx_no`                                                                     AS `trx_no`,
    `a`.`trx_date`                                                                   AS `trx_date`,
    `a`.`supp_code`                                                                  AS `supp_code`,
    `a`.`reff_no`                                                                    AS `reff_no`,
    `a`.`jumlah`                                                                     AS `jumlah`,
    `a`.`trx_status`                                                                 AS `trx_status`,
    `a`.`trx_mode`                                                                   AS `trx_mode`,
    if((`a`.`trx_mode` = 1), 'Manual', 'Auto')                                       AS `xmode`,
    if((`a`.`trx_status` = 1), 'Draft', if((`a`.`trx_status` = 2), 'Close', 'Void')) AS `dtrx_status`,
    `a`.`create_time`                                                                AS `create_time`,
    `a`.`createby_id`                                                                AS `createby_id`,
    `a`.`update_time`                                                                AS `update_time`,
    `a`.`updateby_id`                                                                AS `updateby_id`,
    `b`.`kode`                                                                       AS `outlet_kode`,
    `b`.`outlet_name`                                                                AS `outlet_name`
  FROM (`db_erapos`.`t_payment` `a`
    JOIN `db_erapos`.`m_outlet` `b` ON ((`a`.`outlet_id` = `b`.`id`)))
  ORDER BY `a`.`trx_date`, `a`.`trx_no`;
