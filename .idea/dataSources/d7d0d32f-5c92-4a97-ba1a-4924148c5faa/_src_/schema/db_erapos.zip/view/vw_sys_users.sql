CREATE VIEW vw_sys_users AS
  SELECT
    `a`.`user_uid`                       AS `user_uid`,
    `a`.`is_aktif`                       AS `is_aktif`,
    `a`.`user_email`                     AS `user_email`,
    `a`.`entity_id`                      AS `entity_id`,
    `a`.`outlet_id`                      AS `outlet_id`,
    `a`.`member_of`                      AS `member_of`,
    `a`.`user_pwd`                       AS `user_pwd`,
    `a`.`user_lvl`                       AS `user_lvl`,
    `a`.`employee_id`                    AS `employee_id`,
    `a`.`user_name`                      AS `user_name`,
    `a`.`allow_multiple_login`           AS `allow_multiple_login`,
    `a`.`total_login_attempt`            AS `total_login_attempt`,
    `a`.`status`                         AS `status`,
    `a`.`login_time`                     AS `login_time`,
    `a`.`login_from`                     AS `login_from`,
    `a`.`session_id`                     AS `session_id`,
    `a`.`lock_release_time`              AS `lock_release_time`,
    `a`.`force_accounting_period`        AS `force_accounting_period`,
    `a`.`a_outlet_id`                    AS `a_outlet_id`,
    `a`.`fphoto`                         AS `fphoto`,
    `a`.`createby_id`                    AS `createby_id`,
    `a`.`create_time`                    AS `create_time`,
    `a`.`updateby_id`                    AS `updateby_id`,
    `a`.`update_time`                    AS `update_time`,
    `b`.`entity_cd`                      AS `entity_cd`,
    `b`.`company_name`                   AS `company_name`,
    `b`.`start_date`                     AS `start_date`,
    `c`.`short_desc`                     AS `short_desc`,
    coalesce(`d`.`kode`, 'PST')          AS `kd_outlet`,
    coalesce(`d`.`outlet_name`, 'PUSAT') AS `nm_outlet`,
    `e`.`short_desc`                     AS `ulevel`
  FROM ((((`db_erapos`.`sys_users` `a`
    JOIN `db_erapos`.`sys_company` `b` ON ((`a`.`entity_id` = `b`.`entity_id`))) JOIN `db_erapos`.`sys_status_code` `c`
      ON (((`a`.`status` = `c`.`code`) AND (`c`.`key` = 'login_audit')))) LEFT JOIN `db_erapos`.`m_outlet` `d`
      ON ((`a`.`outlet_id` = `d`.`id`))) JOIN `db_erapos`.`sys_status_code` `e`
      ON (((`a`.`user_lvl` = `e`.`code`) AND (`e`.`key` = 'user_level'))));
