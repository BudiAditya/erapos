CREATE VIEW vw_t_sale_outlet_sum_per_date AS
  SELECT
    `a`.`outlet_id`                         AS `outlet_id`,
    date_format(`a`.`trx_time`, '%Y-%m-%d') AS `trx_date`,
    sum(`a`.`pay_amt`)                      AS `sale_per_date`
  FROM `db_erapos`.`vw_t_sale` `a`
  GROUP BY `a`.`outlet_id`, date_format(`a`.`trx_time`, '%Y-%m-%d');
