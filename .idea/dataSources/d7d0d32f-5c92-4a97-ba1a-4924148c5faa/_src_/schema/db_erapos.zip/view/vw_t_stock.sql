CREATE VIEW vw_t_stock AS
  SELECT
    `a`.`id`          AS `id`,
    `a`.`outlet_id`   AS `outlet_id`,
    `c`.`kode`        AS `outlet_kode`,
    `c`.`outlet_name` AS `outlet_nama`,
    `a`.`sku`         AS `sku`,
    `b`.`nama`        AS `produk_nama`,
    `b`.`satuan`      AS `produk_satuan`,
    `b`.`hrg_beli`    AS `hrg_beli`,
    `b`.`hrg_jual`    AS `hrg_jual`,
    `a`.`qty_awal`    AS `qty_awal`,
    `a`.`qty_in`      AS `qty_in`,
    `a`.`qty_out`     AS `qty_out`,
    `a`.`qty_koreksi` AS `qty_koreksi`,
    `a`.`qty_stok`    AS `qty_stok`
  FROM ((`db_erapos`.`t_stock` `a`
    JOIN `db_erapos`.`m_produk` `b` ON (((`a`.`sku` = `b`.`sku`) AND (`a`.`outlet_id` = `b`.`outlet_id`)))) JOIN
    `db_erapos`.`m_outlet` `c` ON ((`a`.`outlet_id` = `c`.`id`)))
  ORDER BY `a`.`outlet_id`, `a`.`sku`;
