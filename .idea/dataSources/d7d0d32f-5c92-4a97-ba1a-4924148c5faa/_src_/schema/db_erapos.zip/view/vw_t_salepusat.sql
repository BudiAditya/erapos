CREATE VIEW vw_t_salepusat AS
  SELECT
    `a`.`id`                                                              AS `id`,
    `a`.`outlet_id`                                                       AS `outlet_id`,
    `a`.`trx_no`                                                          AS `trx_no`,
    `a`.`trx_date`                                                        AS `trx_date`,
    `a`.`by_outlet_id`                                                    AS `by_outlet_id`,
    `a`.`cust_code`                                                       AS `cust_code`,
    `a`.`ex_po_no`                                                        AS `ex_po_no`,
    `a`.`pay_amt`                                                         AS `pay_amt`,
    `a`.`trx_status`                                                      AS `trx_status`,
    `a`.`notes`                                                           AS `notes`,
    `a`.`create_time`                                                     AS `create_time`,
    `a`.`createby_id`                                                     AS `createby_id`,
    `a`.`update_time`                                                     AS `update_time`,
    `a`.`updateby_id`                                                     AS `updateby_id`,
    `b`.`kode`                                                            AS `outlet_kode`,
    `b`.`outlet_name`                                                     AS `outlet_name`,
    `c`.`kode`                                                            AS `by_outlet_kode`,
    `c`.`outlet_name`                                                     AS `by_outlet_name`,
    `d`.`nama`                                                            AS `cust_name`,
    coalesce(sum(((`a1`.`qty_kirim` * `a1`.`harga`) - `a1`.`diskon`)), 0) AS `sub_total`,
    `e`.`short_desc`                                                      AS `dtrx_status`
  FROM (((((`db_erapos`.`t_salepusat` `a`
    JOIN `db_erapos`.`t_salepusat_detail` `a1` ON ((`a`.`trx_no` = `a1`.`trx_no`))) LEFT JOIN `db_erapos`.`m_outlet` `b`
      ON ((`a`.`outlet_id` = `b`.`id`))) JOIN `db_erapos`.`m_outlet` `c` ON ((`a`.`by_outlet_id` = `c`.`id`))) LEFT JOIN
    `db_erapos`.`m_customer` `d` ON ((`a`.`cust_code` = `d`.`kode`))) JOIN `db_erapos`.`sys_status_code` `e`
      ON (((`a`.`trx_status` = `e`.`code`) AND (`e`.`key` = 'trx_status'))))
  GROUP BY `a`.`trx_no`;
