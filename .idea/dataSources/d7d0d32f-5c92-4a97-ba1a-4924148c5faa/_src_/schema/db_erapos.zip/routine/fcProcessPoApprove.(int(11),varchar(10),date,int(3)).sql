CREATE FUNCTION fcProcessPoApprove(pPoId INT, pStiNo VARCHAR(10), pStiDate DATE, pUid INT(3))
  RETURNS TINYINT(1)
  BEGIN
	
	Declare vOut tinyint Default 0;
	Declare vCnt int;
	Declare vJrc int;

	Declare f_detail_id int;
	Declare f_po_no varchar(10);
	Declare f_sku varchar(10);
	Declare f_qty_order int(5);
	Declare f_harga int;
	Declare f_outlet_id int;
	Declare f_supp_code varchar(10);

	Declare c_porder Cursor For
					Select b.sku,b.qty_order,b.harga,b.id
				  From t_po a Join t_po_detail b On a.po_no = b.po_no Where a.id = pPoId And a.po_status = 0;

  Select count(*) Into vJrc From t_po a Join t_po_detail b On a.po_no = b.po_no Where a.id = pPoId And a.po_status = 0;
	If vJrc > 0 Then
		 
		 Select a.outlet_id,a.po_no,a.supp_code Into f_outlet_id,f_po_no,f_supp_code From t_po a Where a.id = pPoId;
		 
		 Insert Into t_stokin (outlet_id,stokin_no,stokin_date,supp_code,stokin_status,ex_po_no,createby_id,create_time)
									 Values (f_outlet_id,pStiNo,pStiDate,f_supp_code,0,f_po_no,pUid,Now());
		 
		 Set vCnt = 1;
		 Open c_porder;
		 While vCnt <= vJrc Do
			 Fetch c_porder Into f_sku,f_qty_order,f_harga,f_detail_id;
			 
			 Insert Into t_stokin_detail (stokin_no,sku,qty_order,qty_terima,harga)
														Values (pStiNo,f_sku,f_qty_order,f_qty_order,f_harga);
			 
			 Update t_po_detail a Set a.qty_terima = f_qty_order Where a.id = f_detail_id;
			 Set vCnt = vCnt +1;
		 End While;
		 Close c_porder;
		 
		 Update t_po a Set a.po_status = 1,a.updateby_id = pUid,a.update_time = Now() Where a.id = pPoId;
		 Set vOut = 1;
	End If;
	RETURN vOut;
END;
