CREATE FUNCTION fcProcessOpname(pId INT)
  RETURNS TINYINT(1)
  BEGIN
	#Posting Stol Opname
	Declare f_out tinyint default 0;
	Declare f_op_type tinyint default 0;
	Declare f_outlet_id int default 0;
	Declare f_sku varchar(10);
	Declare f_is_posted tinyint(1) default 0;

	Select a.op_type,a.outlet_id,a.sku,a.is_posted Into f_op_type,f_outlet_id,f_sku,f_is_posted From t_stockopname AS a Where a.id = pId;
	If f_is_posted = 0 Then
		If Exists (Select * From t_stock AS a Where a.outlet_id = f_outlet_id And a.sku = f_sku) Then
			 If f_op_type = 1 Then
					Update t_stock a Join t_stockopname b On a.outlet_id = b.outlet_id And a.sku = b.sku
					Set a.qty_awal = a.qty_awal + b.qty Where b.id = pId;
				 Else	
					Update t_stock a Join t_stockopname b On a.outlet_id = b.outlet_id And a.sku = b.sku
					Set a.qty_koreksi = a.qty_koreksi + b.qty Where b.id = pId;
			 End If;
			 Set f_out = 1;
			Else
			 If f_op_type = 1 Then
					Insert t_stock (outlet_id,sku,qty_awal,qty_stok) Select a.outlet_id,a.sku,a.qty,a.qty From t_stockopname a Where a.id = pId;
				 Else	
					Insert t_stock (outlet_id,sku,qty_koreksi,qty_koreksi) Select a.outlet_id,a.sku,a.qty,a.qty From t_stockopname a Where a.id = pId;
			 End If;
			 Set f_out = 1;
		End If;
		If f_out = 1 Then
			 Update t_stock a Set a.qty_stok = (a.qty_awal+a.qty_in+a.qty_koreksi) - a.qty_out Where a.outlet_id = f_outlet_id And a.sku = f_sku;
			 Update t_stockopname a Set a.is_posted = 1 Where a.id = pId;
		End If;
  End If;
	RETURN f_out;
END;
