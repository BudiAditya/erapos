CREATE FUNCTION fcProcessProduksi(pProdNo VARCHAR(10))
  RETURNS INT(3)
  BEGIN
	
	Declare vJrc int default 0;
	Declare vCnt int default 0;

	Declare f_outlet_id int;
	Declare f_sku_bahan varchar(10);
	Declare f_qty_bahan int;
	Declare f_harga_bahan int;
	Declare f_sku_hasil varchar(10);
	Declare f_qty_resep numeric(5,2);
	Declare f_qty_faktor numeric(5,2);
	Declare f_qty_hasil int;
	Declare f_harga_hasil int;
	Declare f_is_stock tinyint default 0;

	Declare v_sku_bahan varchar(10);
	
	Declare c_produksi Cursor For
					Select b.outlet_id, a.sku as sku_bahan,a.qty as qty_bahan,a.harga as harga_bahan,c.sku_utama as sku_hasil,c.qty as qty_resep From t_produksi_detail a Join t_produksi b On a.prod_no = b.prod_no Join m_resep c On a.sku = c.sku
					Where b.prod_status = 0 And a.prod_type = 1 And a.prod_no = pProdNo;

	Select count(*) Into vJrc From t_produksi_detail a Join t_produksi b On a.prod_no = b.prod_no Where b.prod_status = 0 And a.prod_type = 1;
	
	If vJrc > 0 Then
		 
		 Set vCnt = 0;
		 Open c_produksi;
		 Set v_sku_bahan = '-';
		 While vCnt <= vJrc Do
				Fetch c_produksi Into f_outlet_id,f_sku_bahan,f_qty_bahan,f_harga_bahan,f_sku_hasil,f_qty_resep;
			  If f_qty_resep > 0 Then
					 Set f_qty_faktor = round(1/f_qty_resep,2);
					Else
					 Set f_qty_faktor = f_qty_resep;
				End If;
				Set f_qty_hasil = f_qty_bahan * f_qty_faktor;
				Set f_harga_hasil = f_harga_bahan/4;
				
				Insert Into t_produksi_detail (outlet_id,prod_no,prod_type,sku,qty,harga)
															 Values (f_outlet_id,pProdNo,2,f_sku_hasil,f_qty_hasil,f_harga_hasil);

				If v_sku_bahan <> f_sku_bahan Then
					 
					 Select a.is_stock Into f_is_stock From m_produk a Where a.sku = f_sku_bahan And a.outlet_id = f_outlet_id;
					 If f_is_stock > 0 Then
					 	 If Not Exists(Select a.* From t_stock a Where a.sku = f_sku_bahan And a.outlet_id = f_outlet_id) Then
								Insert Into t_stock (outlet_id,sku,qty_in,qty_out,qty_stok)
														 Values (f_outlet_id,f_sku_bahan,0,f_qty_bahan,-f_qty_bahan);
							 Else
								Update t_stock a Set a.qty_out = a.qty_out + f_qty_bahan Where a.sku = f_sku_bahan And a.outlet_id = f_outlet_id;
								Update t_stock a Set a.qty_stok = (a.qty_awal + a.qty_in + a.qty_koreksi) - a.qty_out Where a.sku = f_sku_bahan And a.outlet_id = f_outlet_id;
						 End If;
					 End If;
				End If;
			  
				Select a.is_stock Into f_is_stock From m_produk a Where a.sku = f_sku_hasil And a.outlet_id = f_outlet_id;
			  If f_is_stock > 0 Then
					 If Not Exists(Select a.* From t_stock a Where a.sku = f_sku_hasil And a.outlet_id = f_outlet_id) Then
							Insert Into t_stock (outlet_id,sku,qty_in,qty_out,qty_stok)
													 Values (f_outlet_id,f_sku_hasil,f_qty_hasil,0,f_qty_hasil);
						 Else
							Update t_stock a Set a.qty_in = a.qty_in + f_qty_hasil Where a.sku = f_sku_hasil And a.outlet_id = f_outlet_id;
							Update t_stock a Set a.qty_stok = (a.qty_awal + a.qty_in + a.qty_koreksi) - a.qty_out Where a.sku = f_sku_hasil And a.outlet_id = f_outlet_id;
					 End If;
				End If;
				Set v_sku_bahan = f_sku_bahan;
				Set vCnt = vCnt +1;
		 End While;
		 Close c_produksi;
		 If vCnt > 0 Then
			  Update t_produksi a Set a.prod_status = 1 Where a.prod_no = pProdNo;
		 End If;
	End If;
	RETURN vCnt;
END;
