CREATE FUNCTION fcCancelProcessInventorySaleResep(pOutletId INT(3), pSku VARCHAR(5), pQty INT(5))
  RETURNS TINYINT(1)
  BEGIN
	
	Declare vOut tinyint(1) default 0;
	Declare vJrc int default 0;
	Declare vCnt int default 0;
	Declare f_sku varchar(5);
	Declare f_qty int(5);
	Declare f_istock tinyint(1) default 0;
	Declare c_resep Cursor For
					Select a.sku,a.qty From m_resep a Where a.sku_utama = pSku And a.outlet_id = pOutletId;
	Select count(*) Into vJrc From m_resep a Where a.sku_utama = pSku And a.outlet_id = pOutletId;
	If vJrc > 0 Then
		  Set vCnt = 1;
		  Open c_resep;
			While vCnt <= vJrc Do
				Fetch c_resep Into f_sku,f_qty;
				Select a.is_stock Into f_istock From m_produk a Where a.sku = f_sku And a.outlet_id = pOutletId ;
				If f_istock > 0 Then
					If Exists (Select * From t_stock a Where a.outlet_id = pOutletId And a.sku = f_sku) Then
						 Update t_stock a Set a.qty_out = a.qty_out - (f_qty * pQty) Where a.outlet_id = pOutletId And a.sku = f_sku;
						 Update t_stock a Set a.qty_stok = (a.qty_awal + a.qty_in + a.qty_koreksi) - a.qty_out Where a.outlet_id = pOutletId And a.sku = f_sku;
						Else
						 Insert Into t_stock (outlet_id,sku,qty_in,qty_out,qty_stok)
						 Values (pOutletId,f_sku,0,-(f_qty * pQty),(f_qty * pQty));
					End If;
				End If;
				Set vCnt = vCnt +1;
			End While;
			Set vOut = 1;
			Close c_resep;
	End If;
	RETURN vOut;
END;
