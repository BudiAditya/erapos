CREATE FUNCTION fcCancelProduksi(pProdNo VARCHAR(10))
  RETURNS INT(3)
  BEGIN
	
	Declare vJrc int default 0;
	Declare vCnt int default 0;

	Declare f_outlet_id int;
	Declare f_sku varchar(10);
	Declare f_qty int;
	Declare f_prod_type tinyint default 0;
	Declare f_is_stock tinyint default 0;
	
	Declare c_produksi Cursor For
					Select b.outlet_id,a.prod_type,a.sku,a.qty
					From t_produksi_detail a Join t_produksi b On a.prod_no = b.prod_no 
					Where b.prod_status = 1 And a.prod_no = pProdNo Order By a.id Desc;

	Select count(*) Into vJrc From t_produksi_detail a Join t_produksi b On a.prod_no = b.prod_no Where b.prod_status = 1 And a.prod_no = pProdNo;
	
	If vJrc > 0 Then
		 
		 Set vCnt = 1;
		 Open c_produksi;		 
		 While vCnt <= vJrc Do
				Fetch c_produksi Into f_outlet_id,f_prod_type,f_sku,f_qty;
			  
				Select a.is_stock Into f_is_stock From m_produk a Where a.sku = f_sku And a.outlet_id = f_outlet_id;
			  If f_is_stock > 0 Then
					 If Not Exists(Select a.* From t_stock a Where a.sku = f_sku And a.outlet_id = f_outlet_id) Then
							If f_prod_type = 1 Then
								 Insert Into t_stock (outlet_id,sku,qty_out) Values (f_outlet_id,f_sku,-f_qty);
								Else
								 Insert Into t_stock (outlet_id,sku,qty_in) Values (f_outlet_id,f_sku,-f_qty);
							End If;
							Update t_stock a Set a.qty_stok = (a.qty_awal + a.qty_in + a.qty_koreksi) - a.qty_out Where a.sku = f_sku And a.outlet_id = f_outlet_id;
						 Else
						  If f_prod_type = 1 Then
								 Update t_stock a Set a.qty_out = a.qty_out - f_qty Where a.sku = f_sku And a.outlet_id = f_outlet_id;
							  Else
								 Update t_stock a Set a.qty_in = a.qty_in - f_qty Where a.sku = f_sku And a.outlet_id = f_outlet_id;
							End If;
							Update t_stock a Set a.qty_stok = (a.qty_awal + a.qty_in + a.qty_koreksi) - a.qty_out Where a.sku = f_sku And a.outlet_id = f_outlet_id;
					 End If;
				End If;				
				Set vCnt = vCnt +1;
		 End While;
		 Close c_produksi;
		 If vCnt > 0 Then
			  Update t_produksi a Set a.prod_status = 3 Where a.prod_no = pProdNo;
				Delete a From t_produksi_detail a Where a.prod_no = pProdNo And a.prod_type = 2;
		 End If;
	End If;
	RETURN vCnt;
END;
