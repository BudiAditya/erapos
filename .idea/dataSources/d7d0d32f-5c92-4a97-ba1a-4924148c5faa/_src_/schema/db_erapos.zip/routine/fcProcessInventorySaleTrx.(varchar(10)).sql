CREATE FUNCTION fcProcessInventorySaleTrx(pTrxNo VARCHAR(10))
  RETURNS TINYINT(1)
  BEGIN
	
	Declare vOut tinyint(1) default 0;
	Declare vJrc int default 0;
	Declare vCnt int default 0;
	Declare f_outlet_id int(3);
  Declare f_sku varchar(5);
	Declare f_qty int(5);
	Declare f_result int(5);
	Declare f_ismodifier tinyint(1) default 0;
	Declare f_isresep tinyint(1) default 0;
	Declare f_istock tinyint(1) default 0;
	Declare c_trxsale Cursor For
					Select a.outlet_id,b.sku,b.qty From t_sale a Join t_sale_detail b On a.trx_no = b.trx_no Where a.trx_no = pTrxNo And a.trx_status = 1;
	Select count(*) Into vJrc From t_sale a Join t_sale_detail b On a.trx_no = b.trx_no Where a.trx_no = pTrxNo And a.trx_status = 1;
	If vJrc > 0 Then
		  Set vCnt = 1;
		  Open c_trxsale;
			While vCnt <= vJrc Do
				Fetch c_trxsale Into f_outlet_id,f_sku,f_qty;
				
				Select a.is_modifier,a.is_resep,a.is_stock Into f_ismodifier,f_isresep,f_istock From m_produk a Where a.sku = f_sku and a.outlet_id = f_outlet_id;
				
				If f_ismodifier > 0 Then
					 Select fcProcessInventorySaleModifier(f_outlet_id,f_sku,f_qty) Into f_result;	
				End If;
				
				If f_isresep > 0 Then
					 Select fcProcessInventorySaleResep(f_outlet_id,f_sku,f_qty) Into f_result;	
				End If;
				
				If f_istock > 0 Then
					If Exists (Select * From t_stock a Where a.outlet_id = f_outlet_id And a.sku = f_sku) Then
						 Update t_stock a Set a.qty_out = a.qty_out + f_qty Where a.outlet_id = f_outlet_id And a.sku = f_sku;
						 Update t_stock a Set a.qty_stok = (a.qty_awal + a.qty_in + a.qty_koreksi) - a.qty_out Where a.outlet_id = f_outlet_id And a.sku = f_sku;
						Else
						 Insert Into t_stock (outlet_id,sku,qty_in,qty_out,qty_stok)
						 Values (f_outlet_id,f_sku,0,f_qty,-f_qty);
					End If;
				End If;
				Set vCnt = vCnt +1;
			End While;
			Set vOut = 1;
			Close c_trxsale;
			
			Update t_sale a Set trx_status = 2 Where a.trx_no = pTrxNo And a.trx_status =1;
	End If;
	RETURN vOut;
END;
