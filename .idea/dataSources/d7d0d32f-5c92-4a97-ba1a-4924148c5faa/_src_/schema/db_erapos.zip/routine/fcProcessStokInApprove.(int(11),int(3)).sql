CREATE FUNCTION fcProcessStokInApprove(pStId INT, pUid INT(3))
  RETURNS TINYINT(1)
  BEGIN
	
	Declare vOut tinyint Default 0;
	Declare vCnt int;
	Declare vJrc int;

	Declare f_detail_id int;
	Declare f_stokin_no varchar(10);
	Declare f_sku varchar(10);
	Declare f_qty_terima int(5);
	Declare f_harga int;
	Declare f_outlet_id int;
	Declare f_supp_code varchar(10);
	Declare f_istock tinyint default 0;

	Declare c_stokin Cursor For
					Select b.sku,b.qty_terima,b.harga,b.id
				  From t_stokin a Join t_stokin_detail b On a.stokin_no = b.stokin_no Where a.id = pStId And a.stokin_status = 0;

  Select count(*) Into vJrc From t_stokin a Join t_stokin_detail b On a.stokin_no = b.stokin_no Where a.id = pStId And a.stokin_status = 0;
	If vJrc > 0 Then
		 
		 Select a.outlet_id,a.stokin_no,a.supp_code Into f_outlet_id,f_stokin_no,f_supp_code From t_stokin a Where a.id = pStId;
		 
		 Set vCnt = 1;
		 Open c_stokin;
		 While vCnt <= vJrc Do
			 Fetch c_stokin Into f_sku,f_qty_terima,f_harga,f_detail_id;
			 Select a.is_stock Into f_istock From m_produk a Where a.sku = f_sku And a.outlet_id = f_outlet_id;
				If f_istock > 0 Then
					If Exists (Select * From t_stock a Where a.outlet_id = f_outlet_id And a.sku = f_sku) Then
						 Update t_stock a Set a.qty_in = a.qty_in + f_qty_terima Where a.outlet_id = f_outlet_id And a.sku = f_sku;
						 Update t_stock a Set a.qty_stok = (a.qty_awal + a.qty_in + a.qty_koreksi) - a.qty_out Where a.outlet_id = f_outlet_id And a.sku = f_sku;
						Else
						 Insert Into t_stock (outlet_id,sku,qty_in,qty_out,qty_stok)
						 Values (f_outlet_id,f_sku,f_qty_terima,0,f_qty_terima);
					End If;
				End If;
			 Set vCnt = vCnt +1;
		 End While;
		 Close c_stokin;
		 
		 Update t_stokin a Set a.stokin_status = 1,a.updateby_id = pUid,a.update_time = Now() Where a.id = pStId;
		 Set vOut = 1;
	End If;
	RETURN vOut;
END;
